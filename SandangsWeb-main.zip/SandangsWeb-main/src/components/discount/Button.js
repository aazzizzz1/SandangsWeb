import React from 'react'
//import { useHistory } from "react-router-dom";

function Button() {
    // let history = useHistory();

  // function handleClick() {
  //   history.push("./shops/Shop");
  // }
  return (
    <a href="https://play.google.com/store/apps/details?id=com.fashionizt.cloths">
      <button className='btn-primary'>Desainer</button>
    </a>
  )
}

export default Button