import React from 'react'
//import { useHistory } from "react-router-dom";

function ButtonPre() {
  //   let history = useHistory();

  // function handleClick() {
  //   history.push("TopMitra");
  // }
  return (
    
    <a href="https://play.google.com/store/apps/details?id=com.fashionizt.cloths">
      <button className='btn-primary'>Pre Order</button>
    </a>

    // <button onClick={handleClick} className='btn-primary'>Pre Order</button>
  )
}

export default ButtonPre