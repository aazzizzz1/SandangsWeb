import React from 'react'
// import { useHistory } from "react-router-dom";

function ButtonMall() {
  //   let history = useHistory();

  // function handleClick() {
  //   history.push("TopDesigner");
  // }
  return (
    <a href="https://play.google.com/store/apps/details?id=com.fashionizt.cloths">
      <button className='btn-primary'>Sandang's Mall</button>
    </a>
    //<button onClick={handleClick} className='btn-primary'>Mall</button>
  )
}

export default ButtonMall