import React from 'react'
import { Link} from "react-router-dom"


function ButtonFroom() {
   
  return (
      <div>
        <Link to="/fittingroom">
        <button onClick={{}} className='btn-primary'>Fitting Room</button>  
        </Link>
      </div>
  )
}

export default ButtonFroom