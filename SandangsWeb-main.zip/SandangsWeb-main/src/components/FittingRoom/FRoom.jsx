import React from "react"
import FitRo from "./FitRo";

const Froom = () => {
  return (
    <>
      <section className=''>
        <div className='overflow'>
          <div className='heading-left d_flex'>
            <div className='heading-left row  f_flex'>
            </div>
          </div>
          <FitRo />
        </div>
      </section>
    </>
  )
}

export default Froom