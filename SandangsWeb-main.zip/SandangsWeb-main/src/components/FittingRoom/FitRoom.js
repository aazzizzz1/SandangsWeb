const Fitroom = [
    { 
      cover: "./images/category/jaket.png", 

    },
    { 
      cover: "./images/category/kaos.png", 

    },
    { 
      cover: "./images/category/rok.png", 

    },
    { 
      cover: "./images/category/jeans.png", 
    },
    // {
    //   cover: "./images/category/fitr.jpg"
    // }
  ];

export default Fitroom