const Data = {
  productItems: [
    {
      id: 1,
      discount: 50,
      cover: "./images/flash/mitra-1s.jpeg",
      name: "Chillax",
      price: "Konveksi penyedia kaos terbaik",
    },
    {
      id: 2,
      discount: 40,
      cover: "./images/flash/mitra-11s.jpeg",
      name: "Wbx Studio",
      price: "Konveksi penyedia kemeja terbaik",
    },
    {
      id: 3,
      discount: 40,
      cover: "./images/flash/mitra-3s.jpeg",
      name: "Four Star",
      price: "Konveksi penyedia jaket terbaik",
    },
    {
      id: 4,
      discount: 40,
      cover: "./images/flash/mitra-4s.jpeg",
      name: "GVDNES",
      price: "Konveksi penyedia kaos terbaik",
    },
    {
      id: 5,
      discount: 50,
      cover: "./images/flash/mitra-6s.jpeg",
      name: "Modest Jomi",
      price: "Konveksi penyedia kebaya islami terbaik",
    },
    {
      id: 6,
      discount: 50,
      cover: "./images/flash/mitra-8s.jpeg",
      name: "Gaun",
      price: "Konveksi penyedia gaun terbaik",
    },
  ],
}
export default Data
