import React from 'react'


function Button() {
  return (
    <a href="https://play.google.com/store/apps/details?id=com.fashionizt.cloths">
        <button onClick={{}} className='btn-primary'>View</button>          
    </a>
  )
}

export default Button