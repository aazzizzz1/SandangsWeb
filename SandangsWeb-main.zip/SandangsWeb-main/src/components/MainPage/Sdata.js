const Sdata = [
  {
    id: 1,
    cover: "./images/SlideCard/banner (web).jpg",
    radius: "5px"
  },
  {
    id: 2,
    cover: "./images/SlideCard/banner (web).jpg",
    radius: "5px"
  },
  {
    id: 3,
    cover: "./images/SlideCard/banner (web).jpg",
    radius: "5px"
  },
]
export default Sdata