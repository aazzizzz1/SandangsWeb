const Sdata = {
  shopItems: [
    {
      id: 1,
      cover: "./images/shops/7s.png",
      name: "Jaket",
      price: "180",
      discount: "25",
    },
    {
      id: 2,
      cover: "./images/shops/8s.png",
      name: "Celana",
      price: "120",
      discount: "10",
    },
    {
      id: 3,
      cover: "./images/shops/3s.png",
      name: "Outer",
      price: "20",
      discount: "50 ",
    },
    {
      id: 4,
      cover: "./images/shops/7s.png",
      name: "Jaket",
      price: "999",
      discount: "10 ",
    },
    {
      id: 5,
      cover: "./images/shops/8s.png",
      name: "Celana",
      price: "80",
      discount: "20 ",
    },
    {
      id: 6,
      cover: "./images/shops/3s.png",
      name: "Outer",
      price: "400",
      discount: "20 ",
    },
    {
      id: 7,
      cover: "./images/shops/7s.png",
      name: "Jaket",
      price: "60",
      discount: "5 ",
    },
    {
      id: 8,
      cover: "./images/shops/8s.png",
      name: "Celana",
      price: "120",
      discount: "10",
    },
    {
      id: 9,
      cover: "./images/shops/3s.png",
      name: "Outer",
      price: "5",
      discount: "2",
    },
  ],
}
export default Sdata
